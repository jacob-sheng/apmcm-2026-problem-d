# Supporting Materials — 2026 APMCM Problem D (Team Dapmcm26302266)

## Directory Layout
- `v2_optimized/`: Python source code for crystal-chemistry descriptors (`common_physics.py`), baseline benchmarks (`v1_baseline.py`), Problem 1 hurdle-Bayes surrogate (`v2_surrogate_q1.py`), conformal calibration (`v2_deep_physics_conformal.py`), Problem 2/3 8-bit QUBO/HOBO formulations and exact certification (`v2_qubo_q2_q3.py`), closed-loop and sensitivity benchmarks (`v2_experiments.py`), SPQC-550 hardware decoding (`v2_spqc550_hardware.py`), figure generation (`generate_figures.py`), and the offline runner (`run_all.py`).
- `v2_optimized/results/`: Exported prediction tables, JSON summaries, and saved SPQC-550 raw spin checkpoints (`spqc_checkpoints/`).
- `v2_optimized/figures/`: Figures and diagrams used in the paper.
- `v2_optimized/reference_baselines/`: Reference baseline summary CSVs.
- `scripts/verify_milp_qubo_crosscheck.py`: Independent Fortet-McCormick MILP verification using SciPy/HiGHS.
- `requirements.txt`: Python package versions.

Official competition CSV files and API credentials are excluded.

## Offline Reproduction
Install dependencies from `requirements.txt` (plus `kaiwu==1.4.4`), set `APMCM_DATA_DIR` to the official dataset folder (`date/`), and run:

1. `python v2_optimized/run_all.py --verify-saved` — verify dataset checksums, saved predictions, and SPQC-550 raw spin checkpoints (no cloud API calls).
2. `python scripts/verify_milp_qubo_crosscheck.py` — cross-check all 8 integer Ising ground-state energies via HiGHS MILP (`mip_gap = 0`).
3. `python v2_optimized/run_all.py --all` — run full offline surrogate training, QUBO/HOBO certification, benchmarks, and figure generation.
