# Supporting Materials — 2026 APMCM Problem D (Team Dapmcm26302266)

## Contents
- `v2_optimized/*.py`: Complete, anonymized, reproducible Python source code for:
  - `common_physics.py`: First-principles Periodic Table descriptors, Bartel tau tolerance factor, exact Butler-Ginley log-additive band-center model, Gaussian hinge expectation, and Ising energy sorting.
  - `v1_baseline.py`: Baseline benchmarks (Direct LightGBM, log1p LightGBM, One-Hot FM, and naive 8-bit QUBO).
  - `v2_surrogate_q1.py`: Problem 1 Stage-0 multi-task DFT predictors + 4-family calibrated Bayes-optimal hurdle surrogate + residual/calibration diagnostics + pool scoring.
  - `v2_qubo_q2_q3.py`: Problems 2 & 3 hardware-exact 8-bit active-subspace QUBO/HOBO (Model 3A Submodular HOBO & Model 3B Compact ANOVA) with SA vs. TabuSearch benchmarking.
  - `v2_experiments.py`: Closed-loop FMQA active-screening benchmark (03_val ground truth), bit-width/penalty/cap sensitivity sweeps, and 500-trial Monte Carlo robustness.
  - `v2_spqc550_hardware.py`: Bose Quantum SPQC-550 real optical quantum computer submission & independent raw-spin verification (`--dry-run`, `--run-spqc`, `--verify-only`).
  - `v2_deep_physics_conformal.py`: Site-exchange Butler-Ginley symmetry audit, Mondrian split-conformal coverage, holdout yield curve, and Figure 8 generation.
  - `generate_figures.py` & `run_all.py`: Publication-grade 300 DPI figure generator and one-command pipeline runner.
- `v2_optimized/results/`: All quantitative JSON/CSV summaries, blind holdout predictions (`v2_holdout_04.csv`, `v2_q2_blind_11.csv`, `v2_q3_blind_12.csv`), and raw verified SPQC-550 hardware checkpoints (`spqc_checkpoints/`).
- `v2_optimized/figures/`: All 8 publication-grade 300 DPI English PNG figures (`fig01` through `fig08`).
- `requirements.txt`: Exact Python environment dependencies.

All official raw competition CSV datasets are strictly excluded per APMCM submission rules.

## Reproduction
Place official dataset CSVs in `2026 APMCM Problems/2026 APMCM Problem D/date/` and run:
1. `python v2_optimized/run_all.py`
2. `python v2_optimized/v2_deep_physics_conformal.py`
3. `python v2_optimized/v2_spqc550_hardware.py --verify-only`
